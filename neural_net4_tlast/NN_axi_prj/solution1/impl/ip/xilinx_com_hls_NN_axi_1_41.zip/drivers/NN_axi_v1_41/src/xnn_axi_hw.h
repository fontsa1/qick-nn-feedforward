// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// config
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of window_size
//        bit 31~0 - window_size[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of window_offset
//        bit 31~0 - window_offset[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of scaling_factor
//        bit 31~0 - scaling_factor[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of out_reset
//        bit 31~0 - out_reset[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of out_offset
//        bit 31~0 - out_offset[31:0] (Read)
// 0x34 : Control signal of out_offset
//        bit 0  - out_offset_ap_vld (Read/COR)
//        others - reserved
// 0x40 : Data signal of trig_count
//        bit 31~0 - trig_count[31:0] (Read)
// 0x44 : Control signal of trig_count
//        bit 0  - trig_count_ap_vld (Read/COR)
//        others - reserved
// 0x50 : Data signal of onset_threshold
//        bit 31~0 - onset_threshold[31:0] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of drain_count_last
//        bit 31~0 - drain_count_last[31:0] (Read)
// 0x5c : Control signal of drain_count_last
//        bit 0  - drain_count_last_ap_vld (Read/COR)
//        others - reserved
// 0x68 : Data signal of onset_miss_count
//        bit 31~0 - onset_miss_count[31:0] (Read)
// 0x6c : Control signal of onset_miss_count
//        bit 0  - onset_miss_count_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XNN_AXI_CONFIG_ADDR_WINDOW_SIZE_DATA      0x10
#define XNN_AXI_CONFIG_BITS_WINDOW_SIZE_DATA      32
#define XNN_AXI_CONFIG_ADDR_WINDOW_OFFSET_DATA    0x18
#define XNN_AXI_CONFIG_BITS_WINDOW_OFFSET_DATA    32
#define XNN_AXI_CONFIG_ADDR_SCALING_FACTOR_DATA   0x20
#define XNN_AXI_CONFIG_BITS_SCALING_FACTOR_DATA   32
#define XNN_AXI_CONFIG_ADDR_OUT_RESET_DATA        0x28
#define XNN_AXI_CONFIG_BITS_OUT_RESET_DATA        32
#define XNN_AXI_CONFIG_ADDR_OUT_OFFSET_DATA       0x30
#define XNN_AXI_CONFIG_BITS_OUT_OFFSET_DATA       32
#define XNN_AXI_CONFIG_ADDR_OUT_OFFSET_CTRL       0x34
#define XNN_AXI_CONFIG_ADDR_TRIG_COUNT_DATA       0x40
#define XNN_AXI_CONFIG_BITS_TRIG_COUNT_DATA       32
#define XNN_AXI_CONFIG_ADDR_TRIG_COUNT_CTRL       0x44
#define XNN_AXI_CONFIG_ADDR_ONSET_THRESHOLD_DATA  0x50
#define XNN_AXI_CONFIG_BITS_ONSET_THRESHOLD_DATA  32
#define XNN_AXI_CONFIG_ADDR_DRAIN_COUNT_LAST_DATA 0x58
#define XNN_AXI_CONFIG_BITS_DRAIN_COUNT_LAST_DATA 32
#define XNN_AXI_CONFIG_ADDR_DRAIN_COUNT_LAST_CTRL 0x5c
#define XNN_AXI_CONFIG_ADDR_ONSET_MISS_COUNT_DATA 0x68
#define XNN_AXI_CONFIG_BITS_ONSET_MISS_COUNT_DATA 32
#define XNN_AXI_CONFIG_ADDR_ONSET_MISS_COUNT_CTRL 0x6c


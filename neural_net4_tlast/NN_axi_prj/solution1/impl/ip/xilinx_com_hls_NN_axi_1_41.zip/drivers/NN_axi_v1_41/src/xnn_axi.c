// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xnn_axi.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XNn_axi_CfgInitialize(XNn_axi *InstancePtr, XNn_axi_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Config_BaseAddress = ConfigPtr->Config_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XNn_axi_Set_window_size(XNn_axi *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_axi_WriteReg(InstancePtr->Config_BaseAddress, XNN_AXI_CONFIG_ADDR_WINDOW_SIZE_DATA, Data);
}

u32 XNn_axi_Get_window_size(XNn_axi *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_axi_ReadReg(InstancePtr->Config_BaseAddress, XNN_AXI_CONFIG_ADDR_WINDOW_SIZE_DATA);
    return Data;
}

void XNn_axi_Set_window_offset(XNn_axi *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_axi_WriteReg(InstancePtr->Config_BaseAddress, XNN_AXI_CONFIG_ADDR_WINDOW_OFFSET_DATA, Data);
}

u32 XNn_axi_Get_window_offset(XNn_axi *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_axi_ReadReg(InstancePtr->Config_BaseAddress, XNN_AXI_CONFIG_ADDR_WINDOW_OFFSET_DATA);
    return Data;
}

void XNn_axi_Set_scaling_factor(XNn_axi *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_axi_WriteReg(InstancePtr->Config_BaseAddress, XNN_AXI_CONFIG_ADDR_SCALING_FACTOR_DATA, Data);
}

u32 XNn_axi_Get_scaling_factor(XNn_axi *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_axi_ReadReg(InstancePtr->Config_BaseAddress, XNN_AXI_CONFIG_ADDR_SCALING_FACTOR_DATA);
    return Data;
}

void XNn_axi_Set_out_reset(XNn_axi *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_axi_WriteReg(InstancePtr->Config_BaseAddress, XNN_AXI_CONFIG_ADDR_OUT_RESET_DATA, Data);
}

u32 XNn_axi_Get_out_reset(XNn_axi *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_axi_ReadReg(InstancePtr->Config_BaseAddress, XNN_AXI_CONFIG_ADDR_OUT_RESET_DATA);
    return Data;
}

u32 XNn_axi_Get_out_offset(XNn_axi *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_axi_ReadReg(InstancePtr->Config_BaseAddress, XNN_AXI_CONFIG_ADDR_OUT_OFFSET_DATA);
    return Data;
}

u32 XNn_axi_Get_out_offset_vld(XNn_axi *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_axi_ReadReg(InstancePtr->Config_BaseAddress, XNN_AXI_CONFIG_ADDR_OUT_OFFSET_CTRL);
    return Data & 0x1;
}

u32 XNn_axi_Get_trig_count(XNn_axi *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_axi_ReadReg(InstancePtr->Config_BaseAddress, XNN_AXI_CONFIG_ADDR_TRIG_COUNT_DATA);
    return Data;
}

u32 XNn_axi_Get_trig_count_vld(XNn_axi *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_axi_ReadReg(InstancePtr->Config_BaseAddress, XNN_AXI_CONFIG_ADDR_TRIG_COUNT_CTRL);
    return Data & 0x1;
}

void XNn_axi_Set_onset_threshold(XNn_axi *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_axi_WriteReg(InstancePtr->Config_BaseAddress, XNN_AXI_CONFIG_ADDR_ONSET_THRESHOLD_DATA, Data);
}

u32 XNn_axi_Get_onset_threshold(XNn_axi *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_axi_ReadReg(InstancePtr->Config_BaseAddress, XNN_AXI_CONFIG_ADDR_ONSET_THRESHOLD_DATA);
    return Data;
}

u32 XNn_axi_Get_drain_count_last(XNn_axi *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_axi_ReadReg(InstancePtr->Config_BaseAddress, XNN_AXI_CONFIG_ADDR_DRAIN_COUNT_LAST_DATA);
    return Data;
}

u32 XNn_axi_Get_drain_count_last_vld(XNn_axi *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_axi_ReadReg(InstancePtr->Config_BaseAddress, XNN_AXI_CONFIG_ADDR_DRAIN_COUNT_LAST_CTRL);
    return Data & 0x1;
}

u32 XNn_axi_Get_onset_miss_count(XNn_axi *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_axi_ReadReg(InstancePtr->Config_BaseAddress, XNN_AXI_CONFIG_ADDR_ONSET_MISS_COUNT_DATA);
    return Data;
}

u32 XNn_axi_Get_onset_miss_count_vld(XNn_axi *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_axi_ReadReg(InstancePtr->Config_BaseAddress, XNN_AXI_CONFIG_ADDR_ONSET_MISS_COUNT_CTRL);
    return Data & 0x1;
}



wire kernel_monitor_reset;
wire kernel_monitor_clock;
wire kernel_monitor_report;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
assign kernel_monitor_report = 1'b0;
wire [1:0] axis_block_sigs;
wire [7:0] inst_idle_sigs;
wire [5:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~in_r_TDATA_blk_n;
assign axis_block_sigs[1] = ~grp_NN_axi_Pipeline_LOAD_L_fu_569.in_r_TDATA_blk_n;

assign inst_idle_sigs[0] = grp_NN_fu_597.dense_resource_rf_leq_nin_ap_fixed_ap_fixed_48_32_5_3_0_config2_U0.ap_idle;
assign inst_block_sigs[0] = (grp_NN_fu_597.dense_resource_rf_leq_nin_ap_fixed_ap_fixed_48_32_5_3_0_config2_U0.ap_done & ~grp_NN_fu_597.dense_resource_rf_leq_nin_ap_fixed_ap_fixed_48_32_5_3_0_config2_U0.ap_continue);
assign inst_idle_sigs[1] = grp_NN_fu_597.normalize_ap_fixed_48_32_5_3_0_ap_fixed_32_16_5_3_0_config4_U0.ap_idle;
assign inst_block_sigs[1] = (grp_NN_fu_597.normalize_ap_fixed_48_32_5_3_0_ap_fixed_32_16_5_3_0_config4_U0.ap_done & ~grp_NN_fu_597.normalize_ap_fixed_48_32_5_3_0_ap_fixed_32_16_5_3_0_config4_U0.ap_continue);
assign inst_idle_sigs[2] = grp_NN_fu_597.relu_ap_fixed_32_16_5_3_0_ap_fixed_32_16_5_3_0_relu_config5_U0.ap_idle;
assign inst_block_sigs[2] = (grp_NN_fu_597.relu_ap_fixed_32_16_5_3_0_ap_fixed_32_16_5_3_0_relu_config5_U0.ap_done & ~grp_NN_fu_597.relu_ap_fixed_32_16_5_3_0_ap_fixed_32_16_5_3_0_relu_config5_U0.ap_continue);
assign inst_idle_sigs[3] = grp_NN_fu_597.dense_resource_rf_leq_nin_ap_fixed_ap_fixed_32_16_5_3_0_config6_U0.ap_idle;
assign inst_block_sigs[3] = (grp_NN_fu_597.dense_resource_rf_leq_nin_ap_fixed_ap_fixed_32_16_5_3_0_config6_U0.ap_done & ~grp_NN_fu_597.dense_resource_rf_leq_nin_ap_fixed_ap_fixed_32_16_5_3_0_config6_U0.ap_continue);
assign inst_idle_sigs[4] = grp_NN_fu_597.normalize_ap_fixed_32_16_5_3_0_ap_fixed_16_6_5_3_0_config10_U0.ap_idle;
assign inst_block_sigs[4] = (grp_NN_fu_597.normalize_ap_fixed_32_16_5_3_0_ap_fixed_16_6_5_3_0_config10_U0.ap_done & ~grp_NN_fu_597.normalize_ap_fixed_32_16_5_3_0_ap_fixed_16_6_5_3_0_config10_U0.ap_continue);
assign inst_idle_sigs[5] = grp_NN_fu_597.sigmoid_ap_fixed_16_6_5_3_0_ap_fixed_18_8_5_3_0_sigmoid_config8_U0.ap_idle;
assign inst_block_sigs[5] = (grp_NN_fu_597.sigmoid_ap_fixed_16_6_5_3_0_ap_fixed_18_8_5_3_0_sigmoid_config8_U0.ap_done & ~grp_NN_fu_597.sigmoid_ap_fixed_16_6_5_3_0_ap_fixed_18_8_5_3_0_sigmoid_config8_U0.ap_continue);

assign inst_idle_sigs[6] = 1'b0;
assign inst_idle_sigs[7] = grp_NN_axi_Pipeline_LOAD_L_fu_569.ap_idle;

NN_axi_hls_deadlock_idx0_monitor NN_axi_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);


always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end

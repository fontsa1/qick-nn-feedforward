// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
`timescale 1ns/1ps
module NN_axi_config_s_axi
#(parameter
    C_S_AXI_ADDR_WIDTH = 7,
    C_S_AXI_DATA_WIDTH = 32
)(
    input  wire                          ACLK,
    input  wire                          ARESET,
    input  wire                          ACLK_EN,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] AWADDR,
    input  wire                          AWVALID,
    output wire                          AWREADY,
    input  wire [C_S_AXI_DATA_WIDTH-1:0] WDATA,
    input  wire [C_S_AXI_DATA_WIDTH/8-1:0] WSTRB,
    input  wire                          WVALID,
    output wire                          WREADY,
    output wire [1:0]                    BRESP,
    output wire                          BVALID,
    input  wire                          BREADY,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] ARADDR,
    input  wire                          ARVALID,
    output wire                          ARREADY,
    output wire [C_S_AXI_DATA_WIDTH-1:0] RDATA,
    output wire [1:0]                    RRESP,
    output wire                          RVALID,
    input  wire                          RREADY,
    output wire [31:0]                   window_size,
    output wire [31:0]                   window_offset,
    output wire [31:0]                   scaling_factor,
    output wire [31:0]                   out_reset,
    input  wire [31:0]                   out_offset,
    input  wire                          out_offset_ap_vld,
    input  wire [31:0]                   trig_count,
    input  wire                          trig_count_ap_vld,
    output wire [31:0]                   onset_threshold,
    input  wire [31:0]                   drain_count_last,
    input  wire                          drain_count_last_ap_vld,
    input  wire [31:0]                   onset_miss_count,
    input  wire                          onset_miss_count_ap_vld
);
//------------------------Address Info-------------------
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of window_size
//        bit 31~0 - window_size[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of window_offset
//        bit 31~0 - window_offset[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of scaling_factor
//        bit 31~0 - scaling_factor[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of out_reset
//        bit 31~0 - out_reset[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of out_offset
//        bit 31~0 - out_offset[31:0] (Read)
// 0x34 : Control signal of out_offset
//        bit 0  - out_offset_ap_vld (Read/COR)
//        others - reserved
// 0x40 : Data signal of trig_count
//        bit 31~0 - trig_count[31:0] (Read)
// 0x44 : Control signal of trig_count
//        bit 0  - trig_count_ap_vld (Read/COR)
//        others - reserved
// 0x50 : Data signal of onset_threshold
//        bit 31~0 - onset_threshold[31:0] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of drain_count_last
//        bit 31~0 - drain_count_last[31:0] (Read)
// 0x5c : Control signal of drain_count_last
//        bit 0  - drain_count_last_ap_vld (Read/COR)
//        others - reserved
// 0x68 : Data signal of onset_miss_count
//        bit 31~0 - onset_miss_count[31:0] (Read)
// 0x6c : Control signal of onset_miss_count
//        bit 0  - onset_miss_count_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

//------------------------Parameter----------------------
localparam
    ADDR_WINDOW_SIZE_DATA_0      = 7'h10,
    ADDR_WINDOW_SIZE_CTRL        = 7'h14,
    ADDR_WINDOW_OFFSET_DATA_0    = 7'h18,
    ADDR_WINDOW_OFFSET_CTRL      = 7'h1c,
    ADDR_SCALING_FACTOR_DATA_0   = 7'h20,
    ADDR_SCALING_FACTOR_CTRL     = 7'h24,
    ADDR_OUT_RESET_DATA_0        = 7'h28,
    ADDR_OUT_RESET_CTRL          = 7'h2c,
    ADDR_OUT_OFFSET_DATA_0       = 7'h30,
    ADDR_OUT_OFFSET_CTRL         = 7'h34,
    ADDR_TRIG_COUNT_DATA_0       = 7'h40,
    ADDR_TRIG_COUNT_CTRL         = 7'h44,
    ADDR_ONSET_THRESHOLD_DATA_0  = 7'h50,
    ADDR_ONSET_THRESHOLD_CTRL    = 7'h54,
    ADDR_DRAIN_COUNT_LAST_DATA_0 = 7'h58,
    ADDR_DRAIN_COUNT_LAST_CTRL   = 7'h5c,
    ADDR_ONSET_MISS_COUNT_DATA_0 = 7'h68,
    ADDR_ONSET_MISS_COUNT_CTRL   = 7'h6c,
    WRIDLE                       = 2'd0,
    WRDATA                       = 2'd1,
    WRRESP                       = 2'd2,
    WRRESET                      = 2'd3,
    RDIDLE                       = 2'd0,
    RDDATA                       = 2'd1,
    RDRESET                      = 2'd2,
    ADDR_BITS                = 7;

//------------------------Local signal-------------------
    reg  [1:0]                    wstate = WRRESET;
    reg  [1:0]                    wnext;
    reg  [ADDR_BITS-1:0]          waddr;
    wire [C_S_AXI_DATA_WIDTH-1:0] wmask;
    wire                          aw_hs;
    wire                          w_hs;
    reg  [1:0]                    rstate = RDRESET;
    reg  [1:0]                    rnext;
    reg  [C_S_AXI_DATA_WIDTH-1:0] rdata;
    wire                          ar_hs;
    wire [ADDR_BITS-1:0]          raddr;
    // internal registers
    reg  [31:0]                   int_window_size = 'b0;
    reg  [31:0]                   int_window_offset = 'b0;
    reg  [31:0]                   int_scaling_factor = 'b0;
    reg  [31:0]                   int_out_reset = 'b0;
    reg                           int_out_offset_ap_vld;
    reg  [31:0]                   int_out_offset = 'b0;
    reg                           int_trig_count_ap_vld;
    reg  [31:0]                   int_trig_count = 'b0;
    reg  [31:0]                   int_onset_threshold = 'b0;
    reg                           int_drain_count_last_ap_vld;
    reg  [31:0]                   int_drain_count_last = 'b0;
    reg                           int_onset_miss_count_ap_vld;
    reg  [31:0]                   int_onset_miss_count = 'b0;

//------------------------Instantiation------------------


//------------------------AXI write fsm------------------
assign AWREADY = (wstate == WRIDLE);
assign WREADY  = (wstate == WRDATA);
assign BRESP   = 2'b00;  // OKAY
assign BVALID  = (wstate == WRRESP);
assign wmask   = { {8{WSTRB[3]}}, {8{WSTRB[2]}}, {8{WSTRB[1]}}, {8{WSTRB[0]}} };
assign aw_hs   = AWVALID & AWREADY;
assign w_hs    = WVALID & WREADY;

// wstate
always @(posedge ACLK) begin
    if (ARESET)
        wstate <= WRRESET;
    else if (ACLK_EN)
        wstate <= wnext;
end

// wnext
always @(*) begin
    case (wstate)
        WRIDLE:
            if (AWVALID)
                wnext = WRDATA;
            else
                wnext = WRIDLE;
        WRDATA:
            if (WVALID)
                wnext = WRRESP;
            else
                wnext = WRDATA;
        WRRESP:
            if (BREADY)
                wnext = WRIDLE;
            else
                wnext = WRRESP;
        default:
            wnext = WRIDLE;
    endcase
end

// waddr
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (aw_hs)
            waddr <= AWADDR[ADDR_BITS-1:0];
    end
end

//------------------------AXI read fsm-------------------
assign ARREADY = (rstate == RDIDLE);
assign RDATA   = rdata;
assign RRESP   = 2'b00;  // OKAY
assign RVALID  = (rstate == RDDATA);
assign ar_hs   = ARVALID & ARREADY;
assign raddr   = ARADDR[ADDR_BITS-1:0];

// rstate
always @(posedge ACLK) begin
    if (ARESET)
        rstate <= RDRESET;
    else if (ACLK_EN)
        rstate <= rnext;
end

// rnext
always @(*) begin
    case (rstate)
        RDIDLE:
            if (ARVALID)
                rnext = RDDATA;
            else
                rnext = RDIDLE;
        RDDATA:
            if (RREADY & RVALID)
                rnext = RDIDLE;
            else
                rnext = RDDATA;
        default:
            rnext = RDIDLE;
    endcase
end

// rdata
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (ar_hs) begin
            rdata <= 'b0;
            case (raddr)
                ADDR_WINDOW_SIZE_DATA_0: begin
                    rdata <= int_window_size[31:0];
                end
                ADDR_WINDOW_OFFSET_DATA_0: begin
                    rdata <= int_window_offset[31:0];
                end
                ADDR_SCALING_FACTOR_DATA_0: begin
                    rdata <= int_scaling_factor[31:0];
                end
                ADDR_OUT_RESET_DATA_0: begin
                    rdata <= int_out_reset[31:0];
                end
                ADDR_OUT_OFFSET_DATA_0: begin
                    rdata <= int_out_offset[31:0];
                end
                ADDR_OUT_OFFSET_CTRL: begin
                    rdata[0] <= int_out_offset_ap_vld;
                end
                ADDR_TRIG_COUNT_DATA_0: begin
                    rdata <= int_trig_count[31:0];
                end
                ADDR_TRIG_COUNT_CTRL: begin
                    rdata[0] <= int_trig_count_ap_vld;
                end
                ADDR_ONSET_THRESHOLD_DATA_0: begin
                    rdata <= int_onset_threshold[31:0];
                end
                ADDR_DRAIN_COUNT_LAST_DATA_0: begin
                    rdata <= int_drain_count_last[31:0];
                end
                ADDR_DRAIN_COUNT_LAST_CTRL: begin
                    rdata[0] <= int_drain_count_last_ap_vld;
                end
                ADDR_ONSET_MISS_COUNT_DATA_0: begin
                    rdata <= int_onset_miss_count[31:0];
                end
                ADDR_ONSET_MISS_COUNT_CTRL: begin
                    rdata[0] <= int_onset_miss_count_ap_vld;
                end
            endcase
        end
    end
end


//------------------------Register logic-----------------
assign window_size     = int_window_size;
assign window_offset   = int_window_offset;
assign scaling_factor  = int_scaling_factor;
assign out_reset       = int_out_reset;
assign onset_threshold = int_onset_threshold;
// int_window_size[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_window_size[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_WINDOW_SIZE_DATA_0)
            int_window_size[31:0] <= (WDATA[31:0] & wmask) | (int_window_size[31:0] & ~wmask);
    end
end

// int_window_offset[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_window_offset[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_WINDOW_OFFSET_DATA_0)
            int_window_offset[31:0] <= (WDATA[31:0] & wmask) | (int_window_offset[31:0] & ~wmask);
    end
end

// int_scaling_factor[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_scaling_factor[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCALING_FACTOR_DATA_0)
            int_scaling_factor[31:0] <= (WDATA[31:0] & wmask) | (int_scaling_factor[31:0] & ~wmask);
    end
end

// int_out_reset[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_out_reset[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_OUT_RESET_DATA_0)
            int_out_reset[31:0] <= (WDATA[31:0] & wmask) | (int_out_reset[31:0] & ~wmask);
    end
end

// int_out_offset
always @(posedge ACLK) begin
    if (ARESET)
        int_out_offset <= 0;
    else if (ACLK_EN) begin
        if (out_offset_ap_vld)
            int_out_offset <= out_offset;
    end
end

// int_out_offset_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_out_offset_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (out_offset_ap_vld)
            int_out_offset_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_OUT_OFFSET_CTRL)
            int_out_offset_ap_vld <= 1'b0; // clear on read
    end
end

// int_trig_count
always @(posedge ACLK) begin
    if (ARESET)
        int_trig_count <= 0;
    else if (ACLK_EN) begin
        if (trig_count_ap_vld)
            int_trig_count <= trig_count;
    end
end

// int_trig_count_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_trig_count_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (trig_count_ap_vld)
            int_trig_count_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_TRIG_COUNT_CTRL)
            int_trig_count_ap_vld <= 1'b0; // clear on read
    end
end

// int_onset_threshold[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_onset_threshold[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_ONSET_THRESHOLD_DATA_0)
            int_onset_threshold[31:0] <= (WDATA[31:0] & wmask) | (int_onset_threshold[31:0] & ~wmask);
    end
end

// int_drain_count_last
always @(posedge ACLK) begin
    if (ARESET)
        int_drain_count_last <= 0;
    else if (ACLK_EN) begin
        if (drain_count_last_ap_vld)
            int_drain_count_last <= drain_count_last;
    end
end

// int_drain_count_last_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_drain_count_last_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (drain_count_last_ap_vld)
            int_drain_count_last_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_DRAIN_COUNT_LAST_CTRL)
            int_drain_count_last_ap_vld <= 1'b0; // clear on read
    end
end

// int_onset_miss_count
always @(posedge ACLK) begin
    if (ARESET)
        int_onset_miss_count <= 0;
    else if (ACLK_EN) begin
        if (onset_miss_count_ap_vld)
            int_onset_miss_count <= onset_miss_count;
    end
end

// int_onset_miss_count_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_onset_miss_count_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (onset_miss_count_ap_vld)
            int_onset_miss_count_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_ONSET_MISS_COUNT_CTRL)
            int_onset_miss_count_ap_vld <= 1'b0; // clear on read
    end
end


//------------------------Memory logic-------------------

endmodule
